# 💻 Laptop Consultant Chatbot Using Azure OpenAI

## 📌 Objective
This project builds a conversational chatbot that helps users find suitable laptops based on their needs. It uses Azure OpenAI's chat completion and embedding models, along with ChromaDB for semantic search.

---

## 🧠 Technologies Used
- **Azure OpenAI**: For generating embeddings and chat completions
- **ChromaDB**: For storing and retrieving laptop descriptions via vector similarity
- **Python**: Core scripting language
- **Jupyter Notebook / .py file**: Execution environment

---

## 🛠️ Features
- Accepts user queries like "I need a laptop for gaming"
- Embeds laptop descriptions and user queries using `text-embedding-3-small`
- Retrieves top matching laptops using cosine similarity
- Uses `GPT-4o-mini` to generate personalized recommendations
- Runs automatically through a list of mock queries (no manual input)

---

## 📂 Project Structure
- `practice9.py`: Main script containing chatbot logic
- `README.md`: This file

---

## 🔐 Environment Variables
Set the following before running the script:
```bash
AZURE_OPENAI_EMBEDDING_API_KEY=
AZURE_OPENAI_EMBEDDING_ENDPOINT=
AZURE_OPENAI_EMBED_MODEL=text-embedding-3-small

AZURE_OPENAI_LLM_API_KEY=
AZURE_OPENAI_LLM_ENDPOINT=
AZURE_OPENAI_LLM_MODEL=GPT-4o-mini

Sample Querie
1. I want a lightweight laptop with long battery life for business trips.
2. I need a laptop for gaming with the best graphics card available.
3. Looking for a budget laptop suitable for student tasks and general browsing.


Workflow Summary
- Laptop descriptions are embedded and stored in ChromaDB.
- User query is embedded and matched against stored vectors.
- Top 3 matches are retrieved.
- Chat completion model generates a recommendation based on context.

⚠️ Challenges & Notes
- Azure OpenAI may return InternalServerError if the deployment is misconfigured or temporarily unavailable.
- Ensure all environment variables are correctly set and deployments are active.
- Embedding and LLM calls are wrapped with error handling to avoid crashes.

✅ Submission Checklist
- [x] Environment variables configured
- [x] Sample laptop data embedded
- [x] No manual input (uses mock queries)
- [x] Single .py file with clear comments
- [x] README included
