import os
from langchain.tools import tool
from langchain_openai import AzureChatOpenAI
from langchain_community.utilities import OpenWeatherMapAPIWrapper
from langchain_tavily import TavilySearch
from langgraph.prebuilt import create_react_agent

# Step 1: Setup API keys (replace with your actual keys or set them as environment variables)
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-OkmOJrHqYZb_V_bjOFnC2w"
os.environ["AZURE_DEPLOYMENT_NAME"] = "GPT-4o-mini"
os.environ["OPENWEATHERMAP_API_KEY"] = "db0bc15a4168bc86713800477d0123ee"
os.environ["TAVILY_API_KEY"] = "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"


# Step 2: Define weather tool using Langchain wrapper
weather = OpenWeatherMapAPIWrapper(openweathermap_api_key=os.getenv("OPENWEATHERMAP_API_KEY"))

@tool
def get_weather(city: str) -> str:
    """Get the current weather for a given city."""
    print(f"[Tool] get_weather called for: {city}")
    return weather.run(city)

# Step 3: Initialize Tavily search tool
tavily_search_tool = TavilySearch(
    max_results=1,
    topic="general",
    api_key=os.environ["TAVILY_API_KEY"]
)

# Step 4: Initialize Azure OpenAI LLM
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_DEPLOYMENT_NAME"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_version="2024-07-01-preview",
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

# Step 5: Setup Langchain agent with both tools
tools = [get_weather, tavily_search_tool]
agent = create_react_agent(
    model=llm,
    tools=tools,
)

# Step 6: Simulate conversation loop
print("Welcome to the AI assistant. Type 'exit' to stop.")
messages = []

# Dummy input list for simulation
mock_questions = [
    "What's the weather in Hanoi?",
    "Tell me about the latest news in AI.",
    "Who won the last World Cup?",
    "exit",
]

for user_input in mock_questions:
    print("User:", user_input)
    if user_input.lower() == "exit":
        print("Goodbye!")
        break
    messages.append({"role": "user", "content": user_input})
    response = agent.invoke({"messages": messages})
    messages.append({"role": "assistant", "content": response["messages"][-1].content})
    print("AI:", response["messages"][-1].content)