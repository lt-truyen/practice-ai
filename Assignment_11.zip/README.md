# 🌤️ AI Agent for Weather & Web Search Queries

This project builds a Langchain-based AI assistant that can answer real-time weather and web search queries using OpenWeather and Tavily APIs.

## 🎯 Objective

- Build a conversational agent using Langchain and Azure OpenAI.
- Integrate OpenWeather and Tavily Search as custom tools.
- Simulate a React-style chat loop in Python using dummy inputs.

## 🧩 Features

- 🌦️ Weather queries routed to OpenWeather API.
- 🌐 Web search queries routed to Tavily API.
- 🧠 Langchain agent automatically selects the correct tool.
- 🗨️ Simulated conversation loop with auto input.

## 🛠️ Setup Instructions

### 1. Install dependencies

```bash
pip install langchain openai requests tavily-api tiktoken langchain-openai langchain-community langchain-tavily langgraph pyowm

2. Set environment variables
You can set them in your terminal or directly in the Python file:
export AZURE_OPENAI_ENDPOINT="your-endpoint"
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_DEPLOYMENT_NAME="GPT-4o-mini"
export OPENWEATHERMAP_API_KEY="your-weather-key"
export TAVILY_API_KEY="your-tavily-key"


3. Run the agent
python practice11.py
