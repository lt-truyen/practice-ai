# cloud_detector.py

import os
import base64
import requests
from langchain_openai import AzureChatOpenAI
from pydantic import BaseModel, Field
#Import for displaying images (optional)
#from PIL import Image
#import requests
#from io import BytesIO



# --- Azure OpenAI Config ---
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-OkmOJrHqYZb_V_bjOFnC2w"
os.environ["AZURE_DEPLOYMENT_NAME"] = "GPT-4o-mini"

# --- Setup LLM ---
llm = AzureChatOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
    azure_deployment=os.environ["AZURE_DEPLOYMENT_NAME"],
    api_key=os.environ["AZURE_OPENAI_API_KEY"],
    api_version="2024-02-15-preview",
)

# --- Output Schema ---
class WeatherResponse(BaseModel):
    accuracy: float = Field(description="The accuracy of the result")
    result: str = Field(description="The result of the classification")

llm_with_structured_output = llm.with_structured_output(WeatherResponse)

# --- Dummy Image URLs ---
# Mây sáng, mây tối, nắng, mưa
image_urls = [
    "https://img.freepik.com/free-photo/close-up-blue-sky-with-white-fluffy-cloudy_1258-84766.jpg",
    "https://images.pexels.com/photos/158163/clouds-cloudporn-weather-lookup-158163.jpeg",    
    "https://t3.ftcdn.net/jpg/01/19/18/92/360_F_119189251_kiyixdA3xj8dcCimKuVa4e5DcuslHJPs.jpg"
]

# --- Prompt Template ---
system_prompt = """Based on the satellite image provided, classify the scene as either:
'Clear' (no clouds) or 'Cloudy' (with clouds).
Respond with only one word: either 'Clear' or 'Cloudy' and Accuracy. Do not provide explanations."""

# --- Inference Loop ---
for idx, image_url in enumerate(image_urls):
    print(f"\n--- Processing Image {idx + 1} ---")
    try:
        response = requests.get(image_url)
        image_bytes = response.content
        image_data_base64 = base64.b64encode(image_bytes).decode("utf-8")

        message = [
            {"role": "system", "content": system_prompt},
            {
                "role": "user",
                "content": [
                    {"type": "text", "text": "Classify the scene as either: 'Clear' or 'Cloudy' and Accuracy."},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{image_data_base64}"}},
                ],
            },
        ]

        result = llm_with_structured_output.invoke(message)
        print(f"Prediction: {result.result}")
        print(f"Accuracy: {result.accuracy:.2f} %")
        print(f"Image URL: {image_url}")
        #Show image
        #response = requests.get(image_url)
        #img = Image.open(BytesIO(response.content))
        #img.show()



    except Exception as e:
        print(f"Error processing image {idx + 1}: {e}")