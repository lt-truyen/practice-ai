# ☁️ Satellite Image Cloud Detection via Azure OpenAI

## 🔍 Objective
Build a lightweight Python script that uses Azure OpenAI's multimodal capabilities to classify satellite images as either **"Cloudy"** or **"Clear"** — without needing traditional deep learning models.

---

## 🚀 How It Works
- Accepts satellite image URLs (auto-loaded, no manual input).
- Converts image to base64 and sends it to Azure OpenAI.
- Prompts the LLM to classify the image.
- Returns:
  - Label: "Cloudy" or "Clear"
  - Confidence score
  - Logs everything to console

---

## 🛠️ Setup Instructions

### 1. Install Dependencies

```bash
pip install langchain-openai pillow requests
2. Set Environment Variables
Update these in cloud_detector.py:
os.environ["AZURE_OPENAI_ENDPOINT"] = "your-endpoint"
os.environ["AZURE_OPENAI_API_KEY"] = "your-api-key"
os.environ["AZURE_DEPLOYMENT_NAME"] = "your-deployment-name"


3. Run the Script
python practice12.py




