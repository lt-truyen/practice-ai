🔍 Project Overview
This project builds a semantic search engine for clothing products using Azure OpenAI’s text-embedding-3-small model. It compares product descriptions with a user query using cosine similarity to find the most relevant matches.
🧠 How Embeddings Were Used
- Each product description was converted into a vector using Azure OpenAI.
- The query was also embedded into a vector.
- Cosine similarity was used to compare the query vector with each product vector.
📐 Cosine Similarity
Cosine similarity measures how close two vectors are in direction. A score near 1.0 means high similarity.
def similarity_score(vec1, vec2):
    return 1 - cosine(vec1, vec2)

	
⚠️ Challenges
- Embedding generation can be slow for large datasets.
- Requires secure handling of API keys.
- Semantic similarity depends on quality of descriptions.
✅ Submission Checklist
- [x] Python script with embedded product data
- [x] Dummy query (no manual input)
- [x] Clear comments and structure
- [x] README with explanation and challenges
