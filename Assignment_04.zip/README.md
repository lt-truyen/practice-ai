# 🧠 Azure OpenAI Batch Processor with Function Calling & Retry Logic

## 📌 Overview

This Python module demonstrates efficient usage of the Azure OpenAI API for structured content generation using:

- ✅ Function calling for structured outputs
- ✅ Batch processing of multiple prompts
- ✅ Robust retry logic with exponential backoff using `tenacity`
- ✅ Graceful exception handling

The example use case is **Travel Itinerary Planning**, but the structure is adaptable to other domains like recipe summarization or customer support.

---

## 🚀 How to Run

### 1. Install Dependencies

```bash
pip install openai tenacity

export AZURE_OPENAI_ENDPOINT="https://your-endpoint.openai.azure.com/"
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_DEPLOYMENT_NAME="your-deployment-name"


python practice04.py

batch_inputs = [
    {"prompt": "Plan a travel itinerary.", "destination": "Paris", "days": 3},
    {"prompt": "Plan a travel itinerary.", "destination": "Tokyo", "days": 5},
    {"prompt": "Plan a travel itinerary.", "destination": "New York", "days": 4},
]

📍 Result for Paris:
ChatCompletion object with structured itinerary...

📍 Result for Tokyo:
ChatCompletion object with structured itinerary...

📍 Result for New York:
ChatCompletion object with structured itinerary...