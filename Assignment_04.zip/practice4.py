import os
import time
from openai import AzureOpenAI, RateLimitError, APIError
from tenacity import retry, wait_random_exponential, stop_after_attempt, retry_if_exception_type

# Set environment variables before running
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-lYYMdDxoNzVcT4LdFzyZxg"
os.environ["AZURE_DEPLOYMENT_NAME"] = "GPT-5-mini"

# Initialize Azure OpenAI client
client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

# Define function schema for travel itinerary generation
functions = [
    {
        "name": "generate_itinerary",
        "description": "Generate a travel itinerary for a given destination and duration.",
        "parameters": {
            "type": "object",
            "properties": {
                "destination": {"type": "string", "description": "Travel destination city or country"},
                "days": {"type": "integer", "description": "Number of days to plan for"}
            },
            "required": ["destination", "days"],
        },
    }
]

# Retry decorator for rate limits and transient errors
@retry(
    retry=retry_if_exception_type((RateLimitError, APIError)),
    wait=wait_random_exponential(min=1, max=10),
    stop=stop_after_attempt(5),
    reraise=True
)
def call_openai_function(prompt, destination, days):
    response = client.chat.completions.create(
        model=os.getenv("AZURE_DEPLOYMENT_NAME"),
        messages=[{"role": "user", "content": prompt}],
        functions=functions,
        function_call={
            "name": "generate_itinerary",
            "arguments": f'{{"destination": "{destination}", "days": {days}}}'
        }
    )
    return response

# Batch processing function
def batch_process(inputs):
    results = []
    for input_data in inputs:
        try:
            prompt = input_data["prompt"]
            destination = input_data["destination"]
            days = input_data["days"]
            res = call_openai_function(prompt, destination, days)
            results.append(res)
            time.sleep(1)  # Optional: avoid aggressive rate limit hits
        except Exception as e:
            print(f"❌ Error processing {destination}: {e}")
            results.append(None)
    return results

# Sample batch inputs
batch_inputs = [
    {"prompt": "Plan a travel itinerary.", "destination": "Paris", "days": 3},
    {"prompt": "Plan a travel itinerary.", "destination": "Tokyo", "days": 5},
    {"prompt": "Plan a travel itinerary.", "destination": "New York", "days": 4},
]

# Run batch processing and display results
if __name__ == "__main__":
    outputs = batch_process(batch_inputs)
    for idx, output in enumerate(outputs):
        print(f"\n📍 Result for {batch_inputs[idx]['destination']}:")
        if output:
            print(output)
        else:
            print("No result due to error or retry failure.")
        print("-" * 50)