# Walmart RAG Chatbot

This project implements a Retrieval-Augmented Generation (RAG) chatbot using Azure OpenAI and LangChain to support Walmart product and policy inquiries.

## 🔍 Objective

Help retail staff and customers get instant, accurate answers about Walmart's return policies, warranties, and services using a smart chatbot that references internal documents.

## 🧠 Technologies Used

- Azure OpenAI (Embeddings + GPT-4o-mini)
- LangChain + LangGraph
- FAISS Vector Store
- Python

## 📄 Dataset

15 hardcoded Walmart policy and product entries, such as:

- "Walmart customers may return electronics within 30 days with a receipt and original packaging."
- "Prescription medications purchased at Walmart are not eligible for return or exchange."
- "Bicycles purchased at Walmart can be returned within 90 days if not used outdoors..."

## 🤖 How It Works

1. User question is embedded and matched against document vectors.
2. Top 2 relevant documents are retrieved.
3. GPT-4o-mini generates a human-friendly answer using the retrieved context.

## 💬 Demo Output


## ✅ Benefits of RAG vs. Traditional Search

- Context-aware answers instead of keyword matches
- Handles natural language questions
- Reduces staff training time and improves customer satisfaction

## 🚀 Future Expansion

- Add product recommendation based on user preferences
- Enable multi-turn conversations with memory
- Connect to real-time inventory or order tracking

---

## 🛠 Setup

1. Set your Azure OpenAI credentials as environment variables.
2. Run `practice14.py` to see demo questions and answers.


---

## 📦 Files

- `practice14.py`: Main chatbot implementation
- `README.md`: Project overview and instructions