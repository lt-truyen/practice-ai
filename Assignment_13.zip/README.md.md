# Patient Information Collection and Advisory Chatbot Agent

## 🧠 Overview
This project builds an AI-powered chatbot agent that:
- Collects patient information interactively.
- Provides preliminary health advice.
- Uses LangGraph for dialogue flow.
- Integrates AzureChatOpenAI via LangChain.
- Optionally uses Tavily for real-time web search.

## 🚀 Features
- Conversational AI with guided flow.
- Health advice retrieval from internal documents.
- Optional real-time data enhancement via Tavily.
- Modular design using LangGraph nodes and tools.

## 🛠️ Setup Instructions

### 1. Environment
- Python 3.8+
- Create virtual environment:
  ```bash
  python -m venv venv
  source venv/bin/activate  # or venv\Scripts\activate on Windows

# 2. Install Dependencies
pip install langchain-openai langchain-community langchain_openai langchain-tavily langgraph faiss-cpu


# 3. Configure Environment Variables
Set the following in your .env or directly in the script:
- AZURE_OPENAI_LLM_API_KEY
- AZURE_OPENAI_LLM_ENDPOINT
- AZURE_OPENAI_LLM_MODEL
- AZURE_OPENAI_EMBEDDING_API_KEY
- AZURE_OPENAI_EMBEDDING_ENDPOINT
- AZURE_OPENAI_EMBED_MODEL
- TAVILY_API_KEY (optional)
📦 Files
- patient_chatbot.py: Main Python script with chatbot logic.
- README.md: Documentation and setup guide.
🧪 Sample Inputs & Outputs
Input:
I feel tired and have a sore throat.


# Output:
Patients with a sore throat should drink warm fluids and avoid cold beverages.
Patients experiencing fatigue should consider iron deficiency or poor sleep as potential causes.