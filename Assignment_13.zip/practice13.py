# patient_chatbot.py

import os
from langchain_core.documents import Document
from langgraph.graph import StateGraph, MessagesState, START, END
from langchain_tavily import TavilySearch
from langchain_openai import AzureChatOpenAI, AzureOpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langgraph.prebuilt import ToolNode
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage, HumanMessage

# --- Mock medical advice documents ---
mock_chunks = [
    Document(page_content="Patients with a sore throat should drink warm fluids and avoid cold beverages."),
    Document(page_content="Mild fevers under 38.5°C can often be managed with rest and hydration."),
    Document(page_content="If a patient reports dizziness, advise checking their blood pressure and hydration level."),
    Document(page_content="Persistent coughs lasting more than 2 weeks should be evaluated for infections or allergies."),
    Document(page_content="Patients experiencing fatigue should consider iron deficiency or poor sleep as potential causes."),
]

# --- Environment Variables ---
os.environ["AZURE_OPENAI_EMBEDDING_API_KEY"] = "sk-bgnDyqRaqSjMYeQ2aGiqZg"
os.environ["AZURE_OPENAI_EMBEDDING_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_EMBED_MODEL"] = "text-embedding-3-small"
os.environ["AZURE_OPENAI_LLM_API_KEY"] = "sk-OkmOJrHqYZb_V_bjOFnC2w"
os.environ["AZURE_OPENAI_LLM_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_LLM_MODEL"] = "GPT-4o-mini"
os.environ["TAVILY_API_KEY"] = "sk-bgnDyqRaqSjMYeQ2aGiqZg"

# --- Setup Embedding Model and FAISS Retriever ---
embedding_model = AzureOpenAIEmbeddings(
    model=os.getenv("AZURE_OPENAI_EMBED_MODEL"),
    api_key=os.getenv("AZURE_OPENAI_EMBEDDING_API_KEY"),
    azure_endpoint=os.getenv("AZURE_OPENAI_EMBEDDING_ENDPOINT"),
    api_version="2024-02-15-preview",
)
db = FAISS.from_documents(mock_chunks, embedding_model)
retriever = db.as_retriever()

# --- TOOL 1: Retrieve Advice ---
@tool
def retrieve_advice(user_input: str) -> str:
    """Searches internal documents for relevant patient advice."""
    docs = retriever.invoke(user_input)
    return "\n".join(doc.page_content for doc in docs)

# --- TOOL 2: Tavily Search ---
tavily_tool = TavilySearch()

# --- Setup LLM with Tools ---
llm = AzureChatOpenAI(
    azure_endpoint=os.environ["AZURE_OPENAI_LLM_ENDPOINT"],
    api_key=os.getenv("AZURE_OPENAI_LLM_API_KEY"),
    azure_deployment=os.getenv("AZURE_OPENAI_LLM_MODEL"),
    api_version="2024-02-15-preview",
)
llm_with_tools = llm.bind_tools([retrieve_advice, tavily_tool])

# --- Model Node ---
def call_model(state: MessagesState):
    messages = state["messages"]
    response = llm_with_tools.invoke(messages)
    return {"messages": [response]}

# --- Conditional Routing ---
def should_continue(state: MessagesState):
    last_message = state["messages"][-1]
    if last_message.tool_calls:
        return "tools"
    return END

# --- Tool Node ---
tool_node = ToolNode([retrieve_advice, tavily_tool])

# --- Build LangGraph ---
graph_builder = StateGraph(MessagesState)
graph_builder.add_node("call_model", call_model)
graph_builder.add_node("tools", tool_node)
graph_builder.add_edge(START, "call_model")
graph_builder.add_conditional_edges("call_model", should_continue, ["tools", END])
graph_builder.add_edge("tools", "call_model")
graph = graph_builder.compile()

# --- Dummy Input Simulation ---
if __name__ == "__main__":
    dummy_inputs = [
        "I feel tired and have a sore throat.",
        "I have a mild fever and dizziness.",
        "My cough has lasted more than 2 weeks.",
        "I poor sleep as potential causes"
    ]

    for i, input_text in enumerate(dummy_inputs, 1):
        print(f"\n--- Sample Interaction {i} ---")
        result = graph.invoke({
            "messages": [
                SystemMessage(content="You are a helpful medical assistant. Use tools if needed."),
                HumanMessage(content=input_text),
            ]
        })
        print("Final Response:")
        print(result["messages"][-1].content)