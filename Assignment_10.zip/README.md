# 🛍️ Product Similarity Search with Pinecone & Azure OpenAI

## 🔍 Objective
This project demonstrates how to use Pinecone vector database and Azure OpenAI embeddings to retrieve the top 3 most similar products based on a query description.

## 📦 Dataset
We use a small embedded dataset of 5 products with titles and descriptions:

- Red T-Shirt
- Blue Jeans
- Black Leather Jacket
- White Sneakers
- Green Hoodie

## ⚙️ How It Works
1. **Embedding Generation**: Each product description is converted into a vector using Azure OpenAI's `text-embedding-3-small` model.
2. **Indexing**: These vectors are stored in a Pinecone index.
3. **Querying**: A sample query `"clothing item for summer"` is embedded and used to search the index.
4. **Retrieval**: The top 3 most similar products are returned based on cosine similarity.

## 🧪 Sample Output
Top 3 similar products for the query: 'clothing item for summer'
- Red T-Shirt (Similarity score: 0.8452)
- White Sneakers (Similarity score: 0.8327)
- Blue Jeans (Similarity score: 0.8013)

## 🚀 Setup Instructions
1. Install dependencies:

2. Set your environment variables:
- `AZURE_OPENAI_ENDPOINT`
- `AZURE_OPENAI_API_KEY`
- `AZURE_DEPLOYMENT_NAME`
- `PINECONE_API_KEY`

3. Run the script:

## 🧠 Notes
- No manual input is used; the query is hardcoded.
- The script handles index creation, upsertion, and querying automatically.
- Ensure your Azure and Pinecone accounts are properly configured.

## 🧩 Challenges Faced
- Matching the embedding dimension (1536) with the Pinecone index setup.
- Ensuring proper API key and endpoint configuration for Azure OpenAI.

---

Feel free to customize the query or dataset to explore further!