# product_similarity.py

# pip install pinecone-client openai
import os
from pinecone import Pinecone, ServerlessSpec
from openai import AzureOpenAI

# Step 1: Set environment variables (replace with your actual keys)
os.environ["AZURE_OPENAI_ENDPOINT"] = "https://aiportalapi.stu-platform.live/jpe"
os.environ["AZURE_OPENAI_API_KEY"] = "sk-bgnDyqRaqSjMYeQ2aGiqZg"
os.environ["AZURE_DEPLOYMENT_NAME"] = "text-embedding-3-small"
os.environ["PINECONE_API_KEY"] = "pcsk_7UDsd2_F7KkGZRjGtoeYnpuGe7LsPNrmkNawJBfBkWgzrYFL3wTzHVtiCVUSoA4ZtmA421"

# Step 2: Initialize clients
client = AzureOpenAI(
    api_version="2024-07-01-preview",
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

pc = Pinecone(api_key=os.getenv("PINECONE_API_KEY"))

# Step 3: Create or connect to Pinecone index
index_name = "product-similarity-index"
if index_name not in [index["name"] for index in pc.list_indexes()]:
    pc.create_index(
        name=index_name,
        dimension=1536,
        spec=ServerlessSpec(cloud="aws", region="us-east-1"),
    )
index = pc.Index(index_name)

# Step 4: Sample product dataset
products = [
    {"id": "prod1", "title": "Red T-Shirt", "description": "Comfortable cotton t-shirt in bright red"},
    {"id": "prod2", "title": "Blue Jeans", "description": "Stylish denim jeans with relaxed fit"},
    {"id": "prod3", "title": "Black Leather Jacket", "description": "Genuine leather jacket with classic style"},
    {"id": "prod4", "title": "White Sneakers", "description": "Comfortable sneakers perfect for daily wear"},
    {"id": "prod5", "title": "Green Hoodie", "description": "Warm hoodie made of organic cotton"},
]

# Step 5: Generate embeddings
def get_embedding(text):
    response = client.embeddings.create(
        input=text,
        model=os.getenv("AZURE_DEPLOYMENT_NAME")
    )
    return response.data[0].embedding

vectors = []
for product in products:
    embedding = get_embedding(product["description"])
    vectors.append((product["id"], embedding))

# Step 6: Upsert vectors into Pinecone
index.upsert(vectors)

# Step 7: Query embedding
query = "clothing item for summer"
query_embedding = get_embedding(query)

# Step 8: Search top 3 similar products
top_k = 3
results = index.query(vector=query_embedding, top_k=top_k, include_metadata=False)

# Step 9: Display results
print(f"\nTop {top_k} similar products for the query: '{query}'\n")
for match in results.matches:
    product_id = match.id
    score = match.score
    product = next(p for p in products if p["id"] == product_id)
    print(f"- {product['title']} (Similarity score: {score:.4f})")